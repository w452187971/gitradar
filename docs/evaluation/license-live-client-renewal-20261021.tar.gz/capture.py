import sys, json, copy, hashlib, pathlib, tempfile, subprocess, importlib.util, urllib.request, urllib.parse, base64
from dataclasses import asdict
ROOT=pathlib.Path('/Users/mac/.codex/worktrees/gitradar-v4/gitradar');sys.path.insert(0,str(ROOT))
import gitradar.github_client as gc
from gitradar.models import Budget
from gitradar.sources import boundSourceRequests
from gitradar.evidence import mergeEvidence
from gitradar.content import deriveFacts,resolveContent,eligibleForRecommendation
names=['FreeTubeApp/FreeTube','KDE/kdenlive','WinMerge/winmerge','Zettlr/Zettlr','arsenetar/dupeguru','bleachbit/bleachbit']
OUT=pathlib.Path(tempfile.mkdtemp(prefix='gitradar-license-live-renewal-'));(OUT/'responses').mkdir()
def digest(raw):return hashlib.sha256(raw).hexdigest()
def dump(path,data):path.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
def clean(value):
 if isinstance(value,dict):return {k:clean(v) for k,v in value.items() if k not in ('auth_scope','Authorization','token','password')}
 if isinstance(value,list):return [clean(v) for v in value]
 return value
tracked=['data/evidence.json','data/seed-evidence.json','data/curation.json','data/history.json','data/projects.json','gitradar/github_client.py','gitradar/evidence.py','gitradar/sources.py','gitradar/models.py']
original={p:digest((ROOT/p).read_bytes()) for p in tracked}
evidence=json.loads((ROOT/'data/evidence.json').read_text());curation=json.loads((ROOT/'data/curation.json').read_text());seed=json.loads((ROOT/'data/seed-evidence.json').read_text());projects={p['full_name']:p for p in json.loads((ROOT/'data/projects.json').read_text())['projects']}
previous={n:copy.deepcopy(evidence['projects'][n]) for n in names}; plan=[]
for n in names:
 ref={'full_name':n,'node_id':previous[n]['node_id']};required,errors=boundSourceRequests(previous[n],ref);assert not errors,errors
 sources=required+gc.GitHubClient().defaultSources(ref,required)
 for s in sources:plan.append({'project':n,'url':s.endpoint if s.endpoint.startswith('https://') else gc.API_ROOT+s.endpoint,'source_url':s.url,'kind':s.kind,'web':s.web})
assert len(plan)==25
budget=Budget(rest_requests=25,content_requests=25,max_retries=0,search_requests=0,path_requests=0,identity_requests=0,graphql_points=0,graphql_batches=0)
report={'kind':'manual_selected_six_live_production_client_renewal','head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),'started_at':gc.utcNow(),'directory':str(OUT),'input_hashes':original,'budget':asdict(budget),'plan':plan,'endpoints':[],'wire_attempts':[],'projects':{}}
dump(OUT/'before.json',clean(previous));dump(OUT/'plan.json',plan);dump(OUT/'report.json',report)
allowed={x['url'] for x in plan};active={};realOpen=urllib.request.OpenerDirector.open;realBody=gc.responseBody
# Production redirect handler remains active. This independent guard also counts redirect requests.
def guardedOpen(opener,fullurl,*args,**kwargs):
 req=fullurl if isinstance(fullurl,urllib.request.Request) else urllib.request.Request(fullurl)
 url=req.full_url;parsed=urllib.parse.urlsplit(url)
 if len(report['wire_attempts'])>=25:raise gc.BudgetExceeded('Independent total HTTP cap reached (redirects included).')
 assert req.get_method()=='GET' and parsed.scheme=='https'
 assert parsed.hostname==urllib.parse.urlsplit(active['url']).hostname
 assert not req.has_header('Authorization') or parsed.hostname=='api.github.com'
 row={'url':url,'method':'GET','started_at':gc.utcNow(),'endpoint_number':active['number']};report['wire_attempts'].append(row)
 try:
  response=realOpen(opener,fullurl,*args,**kwargs);row.update(status=response.status,returned_at=gc.utcNow());return response
 except BaseException as exc:
  row.update(error_type=type(exc).__name__,returned_at=gc.utcNow())
  if hasattr(exc,'code'):row['status']=exc.code
  raise

def capturedBody(raw,apiResponse,status):
 stem=f"responses/{active['number']:02d}";path=OUT/(stem+'.body');path.write_bytes(raw)
 active.update(body_file=str(path.relative_to(OUT)),body_sha256=digest(raw),body_bytes=len(raw),http_status=status,body_received_at=gc.utcNow())
 payload=realBody(raw,apiResponse,status)
 if isinstance(payload,dict) and payload.get('encoding')=='base64' and isinstance(payload.get('content'),str):
  decoded=base64.b64decode(payload['content']);(OUT/(stem+'.decoded')).write_bytes(decoded)
  active.update(decoded_file=stem+'.decoded',decoded_sha256=digest(decoded),decoded_bytes=len(decoded),github_blob_sha=payload.get('sha'),blob_sha_valid=hashlib.sha1(b'blob '+str(len(decoded)).encode()+b'\0'+decoded).hexdigest()==payload.get('sha'))
 return payload

def transport(method,url,headers,body):
 global active
 assert url in allowed and method=='GET' and body is None
 active={'number':len(report['endpoints'])+1,'url':url,'started_at':gc.utcNow()};report['endpoints'].append(active)
 try:
  response=gc.httpTransport(method,url,headers,body);active.update(status=response.status,received_at=gc.utcNow());return response
 except BaseException as exc:
  active.update(error_type=type(exc).__name__,received_at=gc.utcNow());raise
 finally:dump(OUT/'report.json',report)

spec=importlib.util.spec_from_file_location('credential_helper',ROOT/'.superpowers/sdd/V4_IMPLEMENTATION_PLAN/github_ops.py');helper=importlib.util.module_from_spec(spec);spec.loader.exec_module(helper)
client=gc.GitHubClient(token=helper.fields['password'],transport=transport)
urllib.request.OpenerDirector.open=guardedOpen;gc.responseBody=capturedBody
merged={}
try:
 for name in names:
  before=previous[name];ref={'full_name':name,'node_id':before['node_id']};fetched=client.readProjectEvidence(ref,copy.deepcopy(before),budget);after=mergeEvidence(before,fetched);merged[name]=after
  assert before['facts']==after['facts'];assert previous[name]==before
  oldrefs={r['id']:r for r in before['refs']};newrefs={r['id']:r for r in after['refs']};ids={i for f in before['facts'].values() if isinstance(f,dict) for i in f.get('ref_ids',[])}|set(curation['projects'][name].get('evidence_hashes',{}))
  rows=[]
  for identity in sorted(ids):
   a=oldrefs[identity];b=newrefs[identity]
   rows.append({'ref_id':identity,'url':a.get('url'),'changed_fields':[k for k in sorted(set(a)|set(b)) if a.get(k)!=b.get(k)],'before':{k:a.get(k) for k in ['content_hash','source_hash','checked_at','status','context_changed','previous_source_hash','previous_hash','path_checked_at','path_status']},'after':{k:b.get(k) for k in ['content_hash','source_hash','checked_at','status','context_changed','previous_source_hash','previous_hash','path_checked_at','path_status']},'text_unchanged':a.get('text')==b.get('text'),'content_hash_valid':digest(b.get('text','').encode())==b.get('content_hash'),'curation_hash_matches':curation['projects'][name].get('evidence_hashes',{}).get(identity)==b.get('content_hash'),'path_fields_unchanged':all(a.get(k)==b.get(k) for k in ['path_checks','path_required_urls','path_checked_at','path_status'])})
  now=gc.utcNow();content=resolveContent(deriveFacts(after),curation['projects'][name],now)
  report['projects'][name]={'node_id':before['node_id'],'status':fetched['status'],'errors':fetched['errors'],'facts_unchanged':before['facts']==after['facts'],'critical_before':before.get('critical_unknowns',[]),'critical_after':after.get('critical_unknowns',[]),'bindings':rows,'eligibility':eligibleForRecommendation(content,projects[name],now),'evaluated_at':now}
  dump(OUT/'after.json',clean(merged));dump(OUT/'report.json',report)
  print(json.dumps({'project':name,'status':fetched['status'],'content_requests':client.usage.content_requests,'wire_attempts':len(report['wire_attempts'])}),flush=True)
finally:
 urllib.request.OpenerDirector.open=realOpen;gc.responseBody=realBody
 client.token=None;helper.fields.clear();helper.credential=None
 report.update(usage=asdict(client.usage),completed_at=gc.utcNow(),inputs_unchanged={p:digest((ROOT/p).read_bytes())==h for p,h in original.items()})
 dump(OUT/'report.json',report)
 files={str(p.relative_to(OUT)):digest(p.read_bytes()) for p in OUT.rglob('*') if p.is_file()};dump(OUT/'MANIFEST.json',files)
 print(json.dumps({'directory':str(OUT),'wire_attempts':len(report['wire_attempts']),'report_sha256':digest((OUT/'report.json').read_bytes())}),flush=True)
