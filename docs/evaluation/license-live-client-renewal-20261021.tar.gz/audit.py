import sys,json,pathlib,hashlib,shutil,tempfile,datetime as dt
ROOT=pathlib.Path('/Users/mac/.codex/worktrees/gitradar-v4/gitradar');sys.path.insert(0,str(ROOT))
from gitradar.sources import visibleSourceText
from gitradar.github_client import REPOSITORY_FACT_FIELDS
from gitradar.evidence import sourceLocation
src=next(pathlib.Path(tempfile.gettempdir()).glob('gitradar-license-live-renewal-*'));dest=pathlib.Path('/tmp')/src.name
if not dest.exists():shutil.copytree(src,dest)
r=json.load(open(dest/'report.json'));before=json.load(open(dest/'before.json'));after=json.load(open(dest/'after.json'))
def sha(raw):return hashlib.sha256(raw).hexdigest()
def dump(p,data):p.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
assert all(r['inputs_unchanged'].values())
assert all(sha((ROOT/p).read_bytes())==h for p,h in r['input_hashes'].items())
assert len(r['endpoints'])==len(r['wire_attempts'])==25
assert all(x['status']==200 for x in r['endpoints'])
assert r['usage']['content_requests']==r['usage']['rest_requests']==25
sourceRows=[];independent=[]
for plan,endpoint in zip(r['plan'],r['endpoints']):
 assert plan['url']==endpoint['url']
 raw=(dest/endpoint['body_file']).read_bytes();assert sha(raw)==endpoint['body_sha256']
 if endpoint.get('decoded_file'):
  decoded=(dest/endpoint['decoded_file']).read_bytes();assert sha(decoded)==endpoint['decoded_sha256'];assert endpoint['blob_sha_valid'];text=decoded.decode()
 elif plan['kind']=='repository':
  payload=json.loads(raw);assert payload['node_id']==before[plan['project']]['node_id'];text=json.dumps({k:payload[k] for k in REPOSITORY_FACT_FIELDS if k in payload},ensure_ascii=False,sort_keys=True)
 else:text=visibleSourceText(raw,'')
 sourceRows.append({'project':plan['project'],'source_url':plan['source_url'],'url':plan['url'],'kind':plan['kind'],'status':endpoint['status'],'received_at':endpoint['received_at'],'body_file':endpoint['body_file'],'body_sha256':endpoint['body_sha256'],'source_sha256':sha(text.encode()),'text':text,'decoded_file':endpoint.get('decoded_file')})
for name,result in r['projects'].items():
 assert before[name]['facts']==after[name]['facts']
 prior={x['id']:x for x in before[name]['refs']};latest={x['id']:x for x in after[name]['refs']}
 for row in result['bindings']:
  old=prior[row['ref_id']];new=latest[row['ref_id']]
  matches=[s for s in sourceRows if s['project']==name and sourceLocation(s['source_url'],s['kind'])==sourceLocation(old['url'],old['source_kind']) and s['kind']==old['source_kind']]
  assert len(matches)==1,(name,row['ref_id'],len(matches));source=matches[0]
  assert new['source_hash']==source['source_sha256'],(name,row['ref_id'],'sourcehash')
  assert row['content_hash_valid'] and row['curation_hash_matches'] and row['text_unchanged'] and row['path_fields_unchanged']
  assert r['started_at']<=source['received_at']<=new['checked_at']<=r['completed_at']
  assert old['checked_at']<new['checked_at']
  context_changed=bool(new.get('context_changed'));hash_changed=old.get('source_hash')!=new['source_hash']
  if context_changed:assert hash_changed or old.get('context_changed');assert new.get('previous_source_hash')==old.get('previous_source_hash',old.get('source_hash'))
  original_supported=(old['text'] in source['text'])
  if old['id']=='repository':
   a=json.loads(old['text']);b=json.loads(source['text']);original_supported=all(k in b and b[k]==v for k,v in a.items())
  assert original_supported,(name,row['ref_id'],'original_text')
  independent.append({'project':name,'ref_id':row['ref_id'],'source_url':source['url'],'original_text_or_metadata_subset_present':True,'source_hash_verified_against_full_response':True,'content_hash_and_curation_match':True,'checked_at':new['checked_at'],'source_hash_changed':hash_changed,'context_changed':context_changed,'path_fields_unchanged':True})
assert len([x for x in independent if x['ref_id']=='license_document_review'])==6
old31ids={'repository','intro','install','license_document_review','license_grant_review'}
# Only FreeTube license_grant_review belongs to the earlier 31-source audit; WinMerge's was excluded.
old31six=[x for x in independent if x['ref_id'] in old31ids and (x['ref_id']!='license_grant_review' or x['project']=='FreeTubeApp/FreeTube')]
assert len(old31six)==25
summary={'kind':r['kind'],'head':r['head'],'started_at':r['started_at'],'completed_at':r['completed_at'],'archive_directory':str(dest),'original_capture_directory':str(src),'report_sha256':sha((dest/'report.json').read_bytes()),'input_hashes':r['input_hashes'],'inputs_unchanged':r['inputs_unchanged'],'usage':r['usage'],'endpoint_count':25,'all_http_200':True,'all_bound_refs_count':len(independent),'earlier_31_bindings_in_six_projects_count':len(old31six),'all_original_facts_unchanged':True,'all_path_fields_unchanged':True,'all_bound_content_hashes_curation_match':True,'all_source_hashes_verified_from_complete_responses':True,'bindings':independent,'endpoints':[{k:v for k,v in s.items() if k!='text'} for s in sourceRows],'projects':{n:{k:v for k,v in p.items() if k!='bindings'} for n,p in r['projects'].items()},'limitations':['Manual selection of six projects, not a normal scheduled collection batch.','No Search/GraphQL/HEAD or retries; observations and path clocks not refreshed.','Not a 14-day sample, all-pool renewal, semantic/model evaluation, or installation/license legal review.','FreeTube releases page whole normalized context changed; no claim as to semantic materiality.','No production data, seed, curation, history, or code modified.']}
dump(dest/'independent-checks.json',summary)
shutil.copy2('/tmp/gitradar-license-live-renewal.py',dest/'capture.py');shutil.copy2('/tmp/gitradar-license-live-audit.py',dest/'audit.py')
manifest={str(p.relative_to(dest)):sha(p.read_bytes()) for p in dest.rglob('*') if p.is_file() and p.name!='MANIFEST.json'};dump(dest/'MANIFEST.json',manifest)
summary['archive_manifest_sha256']=sha((dest/'MANIFEST.json').read_bytes())
dump(ROOT/'docs/evaluation/license-live-client-renewal-checks.json',summary)
print(json.dumps({'archive':str(dest),'all_bound_refs':len(independent),'prior31subset':len(old31six),'changed':[x for x in independent if x['context_changed']],'report_sha256':summary['report_sha256'],'manifest_sha256':summary['archive_manifest_sha256'],'checked_json_sha256':sha((ROOT/'docs/evaluation/license-live-client-renewal-checks.json').read_bytes())},ensure_ascii=False,indent=2))
